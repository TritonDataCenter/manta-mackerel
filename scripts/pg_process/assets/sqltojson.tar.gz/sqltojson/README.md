sqlToJson
=========

Convert PostgreSQL dumps to streaming json
